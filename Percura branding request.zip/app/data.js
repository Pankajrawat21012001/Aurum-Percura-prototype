// Percura UK — synthetic demonstration data + simulation helpers. Not live data.
window.PD = (function () {
  const REGIONS = [
    ['LDN','London','England',51.507,-0.128,184200],['SE','South East','England',51.05,-1.15,141300],
    ['SW','South West','England',50.75,-3.55,89600],['EE','East of England','England',52.35,0.65,96700],
    ['EM','East Midlands','England',52.95,-0.85,72400],['WM','West Midlands','England',52.45,-2.3,88300],
    ['YH','Yorkshire & the Humber','England',53.95,-1.15,83100],['NW','North West','England',53.95,-2.75,109500],
    ['NE','North East','England',55.0,-1.85,40200],['WAL','Wales','Wales',52.25,-3.75,47800],
    ['SCO','Scotland','Scotland',56.7,-4.2,83500],['NI','Northern Ireland','Northern Ireland',54.62,-6.75,28300]
  ].map(a => ({ id:a[0], name:a[1], nation:a[2], lat:a[3], lng:a[4], count:a[5], kind:'region', regionId:a[0] }));
  const C = [
    ['lon-wc','Westminster & Camden','LDN',51.525,-0.14,24800,'local'],['lon-hk','Hackney & Islington','LDN',51.548,-0.072,26100,'local'],
    ['lon-th','Tower Hamlets','LDN',51.515,-0.028,19400,'local'],['lon-sl','Southwark & Lambeth','LDN',51.468,-0.105,28700,'local'],
    ['lon-cr','Croydon','LDN',51.374,-0.098,15200,'local'],['lon-be','Brent & Ealing','LDN',51.53,-0.29,22900,'local'],
    ['lon-gl','Greenwich & Lewisham','LDN',51.458,0.005,18600,'local'],['lon-nh','Newham','LDN',51.53,0.04,14900,'local'],['lon-ba','Barnet','LDN',51.62,-0.2,13600,'local'],
    ['brighton','Brighton & Hove','SE',50.83,-0.14,18400,'city'],['oxford','Oxford','SE',51.75,-1.26,14200,'city'],['reading','Reading','SE',51.455,-0.97,13100,'city'],
    ['soton','Southampton','SE',50.91,-1.40,16800,'city'],['canterbury','Canterbury','SE',51.28,1.08,7300,'city'],['mk','Milton Keynes','SE',52.04,-0.76,12600,'city'],
    ['bristol','Bristol','SW',51.455,-2.59,31200,'city'],['plymouth','Plymouth','SW',50.375,-4.14,14100,'city'],['exeter','Exeter','SW',50.72,-3.53,9800,'city'],
    ['bath','Bath','SW',51.38,-2.36,7600,'late'],['bournemouth','Bournemouth','SW',50.72,-1.88,12400,'city'],
    ['cambridge','Cambridge','EE',52.205,0.12,15300,'city'],['norwich','Norwich','EE',52.63,1.30,13100,'city'],['ipswich','Ipswich','EE',52.06,1.15,8600,'city'],['peterborough','Peterborough','EE',52.57,-0.24,9900,'city'],
    ['nottingham','Nottingham','EM',52.95,-1.15,22400,'city'],['leicester','Leicester','EM',52.635,-1.13,21800,'city'],['derby','Derby','EM',52.92,-1.48,12300,'late'],['lincoln','Lincoln','EM',53.23,-0.54,6900,'city'],
    ['birmingham','Birmingham','WM',52.48,-1.89,48600,'city'],['coventry','Coventry','WM',52.41,-1.51,16200,'city'],['wolves','Wolverhampton','WM',52.585,-2.13,11400,'late'],['stoke','Stoke-on-Trent','WM',53.0,-2.18,10300,'city'],
    ['leeds','Leeds','YH',53.80,-1.55,33800,'city'],['sheffield','Sheffield','YH',53.38,-1.47,25600,'city'],['bradford','Bradford','YH',53.795,-1.76,14900,'late'],['hull','Hull','YH',53.745,-0.34,11200,'city'],['york','York','YH',53.96,-1.08,8400,'city'],
    ['manchester','Manchester','NW',53.48,-2.24,52300,'city'],['liverpool','Liverpool','NW',53.41,-2.98,31700,'city'],['preston','Preston','NW',53.76,-2.70,7900,'city'],['lancaster','Lancaster','NW',54.05,-2.80,5100,'city'],
    ['newcastle','Newcastle','NE',54.98,-1.61,21600,'city'],['sunderland','Sunderland','NE',54.906,-1.38,9800,'late'],['boro','Middlesbrough','NE',54.575,-1.235,7400,'city'],
    ['cardiff','Cardiff','WAL',51.48,-3.18,22100,'city'],['swansea','Swansea','WAL',51.62,-3.94,10900,'city'],['newport','Newport','WAL',51.585,-2.998,6800,'late'],['wrexham','Wrexham','WAL',53.046,-2.99,4200,'city'],
    ['glasgow','Glasgow','SCO',55.86,-4.25,31400,'city'],['edinburgh','Edinburgh','SCO',55.95,-3.19,27900,'city'],['aberdeen','Aberdeen','SCO',57.15,-2.09,11200,'city'],['dundee','Dundee','SCO',56.46,-2.97,7100,'city'],['inverness','Inverness','SCO',57.48,-4.22,3900,'city'],
    ['belfast','Belfast','NI',54.60,-5.93,17800,'city'],['derry','Derry / Londonderry','NI',54.997,-7.32,5400,'city'],['newry','Newry','NI',54.18,-6.34,2300,'city']
  ];
  const RMAP = {}; REGIONS.forEach(r => RMAP[r.id] = r);
  const CLUSTERS = C.map(a => ({ id:a[0], name:a[1], regionId:a[2], lat:a[3], lng:a[4], count:a[5], tier:a[6], kind:a[6]==='local'?'local':'city', nation:RMAP[a[2]].nation }));
  const ALL = {}; REGIONS.concat(CLUSTERS).forEach(x => ALL[x.id] = x);
  const TOTAL = REGIONS.reduce((s, r) => s + r.count, 0);
  ALL.UK = { id:'UK', name:'United Kingdom', kind:'uk', count:TOTAL, nation:'', regionId:null };

  const SEGS = {
    yp:{ name:'Young professional', color:'#E85D3A', age:[24,35], inc:['£32–45k','£45–60k','£60–80k'], hh:['Lives alone','House-share','Lives with partner'],
      occ:['Software developer','Marketing executive','Junior solicitor','Data analyst','Account manager','UX designer','Management consultant','Nurse practitioner'],
      int:['Fitness','Travel','Podcasts','Specialty coffee','Live music','Running clubs','Cooking','Budget apps'],
      buy:['Compares prices on mobile before buying','Subscription-heavy; cancels fast when value drops','Pays more for convenience and fast delivery'],
      att:['Values flexibility over long-term commitments','Sceptical of brands, trusts peer reviews','Ambitious, time-poor, career-focused'] },
    fam:{ name:'Family household', color:'#2F6F5E', age:[32,50], inc:['£35–50k household','£50–75k household','£75k+ household'], hh:['Married, 2 children','Partner, 1 child','Single parent, 2 children','Married, 3 children'],
      occ:['Primary school teacher','Project manager','Electrician','HR advisor','Pharmacist','Civil servant','Retail manager'],
      int:['Days out','Home improvement','Meal planning','Kids’ football','Gardening','Family holidays','Batch cooking'],
      buy:['Big weekly shop, loyalty-card driven','Waits for deals; plans purchases ahead','Brand loyal for kids’ essentials, own-label elsewhere'],
      att:['Budget-conscious, values reliability','Time-pressed, wants things that just work','Cautious about change, trusts familiar names'] },
    ret:{ name:'Retiree', color:'#5B6CA8', age:[64,82], inc:['State pension','State + workplace pension','Comfortable pension'], hh:['Married, grown-up children','Widowed, lives alone','Lives with partner'],
      occ:['Retired teacher','Retired engineer','Retired nurse','Retired shop owner','Retired civil servant','Retired bus driver'],
      int:['Gardening','Grandchildren','Local history','Walking groups','Radio 4','Crosswords','Volunteering'],
      buy:['Prefers in-store, values good service','Reads the small print; dislikes subscriptions','Loyal to trusted brands for decades'],
      att:['Wary of digital-only services','Community-minded, values fairness','Careful with money, dislikes waste'] },
    stu:{ name:'Student', color:'#B7832A', age:[18,24], inc:['Maintenance loan','Loan + part-time job','Parental support'], hh:['Student halls','House-share','Lives with parents'],
      occ:['Undergraduate, Economics','Undergraduate, Nursing','Master’s student, Design','Undergraduate, Computer Science','Apprentice','Undergraduate, Law'],
      int:['Gaming','TikTok','Gigs','Thrifting','Gym','Cooking on a budget','Climate action'],
      buy:['Extremely price-sensitive; hunts student discounts','Buy-now-pay-later user','Follows creators for product picks'],
      att:['Idealistic about climate and fairness','Digital-native, low brand loyalty','Anxious about money and housing'] },
    smb:{ name:'Small business owner', color:'#7A4E8C', age:[30,60], inc:['£30–50k','£50–90k','Variable income'], hh:['Married, 1 child','Lives with partner','Married, 2 children'],
      occ:['Café owner','Plumbing firm owner','Independent retailer','Hair salon owner','Freelance accountant','Builder (sole trader)'],
      int:['Local networking','Football','Business podcasts','DIY','Property','Cycling'],
      buy:['Buys on value and reliability; negotiates','Researches heavily, then commits long-term','Supports other local businesses'],
      att:['Pragmatic, distrusts red tape','Self-reliant, cost-focused','Optimistic but cash-flow anxious'] },
    key:{ name:'Key worker', color:'#3F8FA6', age:[25,58], inc:['£24–32k','£32–40k','£40–48k'], hh:['Partner, 1 child','Lives alone','Married, 2 children','Single parent, 1 child'],
      occ:['NHS nurse','Care worker','Bus driver','Police officer','Warehouse supervisor','Paramedic','Supermarket team leader'],
      int:['Football','Takeaway nights','Family time','Walking the dog','Box sets','Fishing'],
      buy:['Shops discounters; switches for savings','Buys when paid, budgets week to week','Values practical, no-frills products'],
      att:['Feels overlooked by decision-makers','Hard-working, values fairness','Sceptical of promises, wants proof'] }
  };
  const SEG_KEYS = Object.keys(SEGS);
  const FIRST = ['Olivia','Amelia','Isla','Ava','Mia','Sophie','Grace','Freya','Chloe','Emily','Hannah','Priya','Aisha','Zara','Niamh','Siobhan','Megan','Rhiannon','Eilidh','Fatima','Leah','Charlotte','Ellie','Ruby','Jack','Oliver','Harry','George','Noah','Charlie','Thomas','James','William','Liam','Callum','Rhys','Owen','Ewan','Mohammed','Arjun','Kwame','Daniel','Sam','Ryan','Connor','Jamie','Tom','Ben','Adam','Hamza','Kieran','Ciaran','Dylan','Joseph','Margaret','Pauline','Brian','Keith'];
  const LAST = ['Smith','Jones','Taylor','Brown','Williams','Wilson','Johnson','Davies','Patel','Robinson','Wright','Thompson','Evans','Walker','White','Roberts','Green','Hall','Wood','Jackson','Clarke','Khan','Hughes','Edwards','Campbell','MacDonald','Murphy','O’Neill','Kaur','Ahmed','Begum','Okafor','Mensah','Lewis','Morgan','Price','Reid','Stewart','Fraser','Kelly','Quinn','Shaw','Bennett','Ali','Hussain','Singh','Chen','Nowak'];

  const HEADLINES = [
    { cat:'Economy', t:'Energy price cap to rise 6% from January' },
    { cat:'Transport', t:'£2 bus fare cap extended for another two years' },
    { cat:'Retail', t:'Major supermarket trials checkout-free stores in Manchester' },
    { cat:'Housing', t:'Councils given powers to double council tax on second homes' },
    { cat:'Health', t:'NHS App to offer same-day GP booking nationwide' },
    { cat:'Economy', t:'Bank of England holds interest rate, signals a cut in spring' },
    { cat:'Environment', t:'Ban on new petrol car sales brought forward to 2030' },
    { cat:'Media', t:'Streaming services face new levy to fund public broadcasting' }
  ];
  const EVENT_TYPES = ['Price change','Product launch','Policy change','Campaign'];
  const EVENT_PRESETS = [
    { type:'Product launch', title:'£4.99/month grocery delivery pass', desc:'Unlimited free next-day grocery delivery on orders over £25, cancel anytime.' },
    { type:'Price change', title:'Mobile plans rise £3/month mid-contract', desc:'Major UK network raises all pay-monthly plans by £3 from April, citing inflation.' },
    { type:'Campaign', title:'“Shop Local Saturdays” high-street campaign', desc:'Councils and independent shops offer 20% off and free parking every Saturday in March.' }
  ];

  function hash(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  function rng(seed) { let a = seed; return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
  const pick = (r, arr) => arr[Math.floor(r() * arr.length)];
  function wpick(r, items, w) { const tot = items.reduce((s, it) => s + w(it), 0); let x = r() * tot; for (const it of items) { x -= w(it); if (x <= 0) return it; } return items[items.length - 1]; }
  const fmt = n => Math.round(n).toLocaleString('en-GB');
  const fmtK = n => n >= 1e6 ? (n / 1e6).toFixed(2) + 'M' : n >= 1000 ? Math.round(n / 1000) + 'k' : String(n);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const get = id => ALL[id] || ALL.UK;

  function visibleAt(z) {
    if (z < 7) return REGIONS;
    const out = CLUSTERS.filter(c => c.tier === 'city' || (c.tier === 'late' && z >= 8.5) || (c.tier === 'local' && z >= 10));
    if (z < 10) out.push(Object.assign({}, RMAP.LDN, { kind:'city', name:'Greater London' }));
    return out;
  }

  const UNI = new Set(['oxford','cambridge','york','lancaster','exeter','bath','canterbury','edinburgh','glasgow','cardiff','nottingham','leeds','manchester','bristol','lon-wc','lon-hk','dundee','swansea']);
  const BASE = { yp:.17, fam:.27, ret:.2, stu:.09, smb:.11, key:.16 };
  const mixCache = {};
  function mix(id) {
    if (mixCache[id]) return mixCache[id];
    let m;
    if (id === 'UK') {
      m = {}; SEG_KEYS.forEach(k => m[k] = 0);
      REGIONS.forEach(r => { const rm = mix(r.id); SEG_KEYS.forEach(k => m[k] += rm[k] * r.count / TOTAL); });
      return (mixCache[id] = m);
    }
    const info = get(id), r = info.regionId; m = Object.assign({}, BASE);
    if (r === 'LDN') { m.yp += .12; m.ret -= .08; m.stu += .02; }
    if (r === 'SW') { m.ret += .08; m.yp -= .03; }
    if (r === 'NE' || r === 'YH' || r === 'WM') m.key += .04;
    if (r === 'SE' || r === 'EE') { m.fam += .03; m.smb += .02; }
    if (r === 'SCO' || r === 'WAL' || r === 'NI') { m.ret += .03; m.smb += .01; }
    if (UNI.has(id)) m.stu += .09;
    if (info.kind !== 'region') { m.yp += .03; m.ret -= .02; }
    const rnd = rng(hash(id + ':mix'));
    SEG_KEYS.forEach(k => m[k] = Math.max(.03, m[k] * (0.85 + rnd() * 0.3)));
    const s = SEG_KEYS.reduce((a, k) => a + m[k], 0); SEG_KEYS.forEach(k => m[k] /= s);
    return (mixCache[id] = m);
  }

  const pCache = {};
  function personas(id, n) {
    if (!pCache[id]) {
      const r = rng(hash(id + ':people')), info = get(id), out = [];
      for (let i = 0; i < 120; i++) {
        let loc;
        if (info.kind === 'uk') { const reg = wpick(r, REGIONS, x => x.count); const cs = CLUSTERS.filter(c => c.regionId === reg.id); loc = cs.length ? wpick(r, cs, x => x.count) : reg; }
        else if (info.kind === 'region') { const cs = CLUSTERS.filter(c => c.regionId === id); loc = cs.length && r() > .25 ? wpick(r, cs, x => x.count) : info; }
        else loc = info;
        const lm = mix(loc.id);
        const sk = wpick(r, SEG_KEYS, k => lm[k]), S = SEGS[sk];
        const first = pick(r, FIRST), last = pick(r, LAST);
        const ints = []; while (ints.length < 3) { const x = pick(r, S.int); if (!ints.includes(x)) ints.push(x); }
        const reg = RMAP[loc.regionId];
        out.push({ id:id + '-' + i, name:first + ' ' + last, initials:first[0] + last.replace(/[^A-Za-z]/g, '')[0], seg:sk, segName:S.name, color:S.color,
          age:S.age[0] + Math.floor(r() * (S.age[1] - S.age[0] + 1)), occ:pick(r, S.occ), income:pick(r, S.inc), hh:pick(r, S.hh),
          interests:ints, buy:pick(r, S.buy), att:pick(r, S.att), loc:loc.kind === 'region' ? reg.name : loc.name, regionId:reg.id, regionName:reg.name, nation:reg.nation,
          clusterId:loc.id, bias:(r() - .5) * .8 });
      }
      pCache[id] = out;
    }
    return pCache[id].slice(0, n || 24);
  }

  function scopeOptions() {
    const o = [{ v:'UK', l:'United Kingdom — all regions' }];
    REGIONS.forEach(r => {
      o.push({ v:r.id, l:r.name });
      CLUSTERS.filter(c => c.regionId === r.id).forEach(c => o.push({ v:c.id, l:'\u00a0\u00a0\u00a0\u00a0' + c.name }));
    });
    return o;
  }

  // ---------- heuristic reaction model ----------
  const TOPICS = [
    { k:['price','cost','bill','energy','inflation','fare','rent','mortgage','tax','vat','fee','levy','charge','interest rate','£'], theme:'Cost of living', cost:true, w:{ yp:-.6, fam:-1.2, ret:-1, stu:-1.1, smb:-.8, key:-1.2 } },
    { k:['app','ai ','digital','online','tech','checkout-free','subscription','streaming','contactless','delivery'], theme:'Digital adoption', w:{ yp:.8, fam:.3, ret:-.7, stu:.7, smb:.2, key:.1 } },
    { k:['electric','petrol','green','net zero','solar','recycl','climate','sustainab','emission'], theme:'Sustainability', w:{ yp:.4, fam:-.1, ret:-.5, stu:.8, smb:-.4, key:-.3 } },
    { k:['nhs','health','gp ','hospital','care','doctor'], theme:'Public services', w:{ yp:.3, fam:.5, ret:.8, stu:.2, smb:.2, key:.6 } },
    { k:['business','high street','shop local','independent','local'], theme:'Local economy', w:{ yp:.1, fam:.2, ret:.4, stu:0, smb:.9, key:.1 } },
    { k:['house','housing','second home','first-time','landlord'], theme:'Housing', w:{ yp:.5, fam:.2, ret:-.4, stu:.4, smb:-.2, key:.4 } },
    { k:['bus','train','rail','transport','commute','parking'], theme:'Transport', w:{ yp:.3, fam:.3, ret:.5, stu:.7, smb:.2, key:.6 } }
  ];
  const UP = ['rise','rises','increase','hike','higher','raise','double','mid-contract'];
  const DOWN = ['cut','freeze','lower','discount','cheaper','reduce','extended','free ','save','saving','holds','% off','off and free'];
  function analyse(text) {
    const t = ' ' + text.toLowerCase() + ' ';
    const up = UP.some(w => t.includes(w)), down = DOWN.some(w => t.includes(w));
    const hits = TOPICS.filter(tp => tp.k.some(k => t.includes(k))).slice(0, 2);
    const launch = /launch|new |introduc|trial|pass|offer/.test(t);
    return { hits, flip: hits.length && down && !up, launch, theme: hits.length ? hits[0].theme : 'General interest' };
  }
  function heur(text, p, a, intensity) {
    const r = rng(hash(text + '|' + p.id));
    let s = 0;
    a.hits.forEach(tp => { let w = tp.w[p.seg] || 0; if (tp.cost && a.flip) w = -w * .9; s += w; });
    if (!a.hits.length) s += { yp:.3, stu:.25, fam:.05, ret:-.15, smb:.05, key:0 }[p.seg];
    if (a.launch) s += .25;
    s = s * (intensity || 1) + p.bias + (r() - .5) * 1.4;
    return clamp(s, -2, 2);
  }
  const BUCKETS = [
    { k:-2, label:'Strongly negative', color:'#A8321C' }, { k:-1, label:'Negative', color:'#E8957F' },
    { k:0, label:'Neutral', color:'#CFCAC2' }, { k:1, label:'Positive', color:'#8DBFA8' }, { k:2, label:'Strongly positive', color:'#2F6F5E' }];
  const bucketOf = s => BUCKETS[clamp(Math.round(s), -2, 2) + 2];
  const CON = { yp:'rent already eats half my pay', fam:'the weekly shop is stretched enough', ret:'my pension doesn’t go as far as it used to', stu:'my maintenance loan barely covers rent', smb:'margins are thin enough as it is', key:'shift pay hasn’t kept up with anything' };
  const HOOK = { yp:'anything that saves me time is a win', fam:'if it makes family life a bit easier, I’m in', ret:'as long as it’s straightforward to use', stu:'if it’s cheap, my flatmates will be all over it', smb:'could be good for footfall round here', key:'something that actually helps people like us for once' };
  const NEG = ['Honestly, not what we need right now — {c}.', 'I can see who this hurts, and it’s people like me. {C}.', 'I’d push back on this. {C}, and this makes it worse.'];
  const NEU = ['I’d need to see the detail before making my mind up.', 'Doesn’t change much for me day to day, to be honest.', 'Could go either way. Depends how it’s rolled out in {loc}.'];
  const POS = ['Sounds sensible, actually — {h}.', 'About time. {H}.', 'I’d give it a go. {H}.'];
  const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
  function fallbackQuote(text, p, s) {
    const r = rng(hash('q' + text + p.id));
    const tpl = pick(r, s <= -.5 ? NEG : s >= .5 ? POS : NEU);
    return tpl.replace('{c}', CON[p.seg]).replace('{C}', cap(CON[p.seg])).replace('{h}', HOOK[p.seg]).replace('{H}', cap(HOOK[p.seg])).replace('{loc}', p.loc);
  }
  const describe = p => `${p.name}, ${p.age}, ${p.occ}, ${p.loc} (${p.regionName}). Segment: ${p.segName}. ${p.hh}. Income: ${p.income}. Interests: ${p.interests.join(', ')}. Buying: ${p.buy}. Outlook: ${p.att}.`;

  async function aiReact(text, list, kindLabel) {
    if (!window.claude || !window.claude.complete) return null;
    const prompt = `You are simulating how synthetic UK consumer personas react to a stimulus.\nStimulus (${kindLabel}): "${text}"\n\nPersonas:\n${list.map((p, i) => (i + 1) + '. ' + describe(p)).join('\n')}\n\nReact in character for each persona, reflecting their circumstances. Use a realistic spread of opinions. Return ONLY a JSON array with one object per persona in order: {"n":<persona number>,"s":<integer sentiment from -2 to 2>,"q":"<first-person reaction, max 28 words, natural British English>","t":"<main theme, 1-3 words>"}`;
    const out = await window.claude.complete(prompt);
    const m = String(out).match(/\[[\s\S]*\]/); if (!m) return null;
    const arr = JSON.parse(m[0]);
    const res = list.map((p, i) => { const o = arr.find(x => x.n === i + 1) || arr[i]; return o && o.q ? { p, s:clamp(Number(o.s) || 0, -2, 2), q:String(o.q), t:cap(String(o.t || 'General').toLowerCase()) } : null; });
    return res.every(Boolean) ? res : null;
  }

  function decorate(x) { const b = bucketOf(x.s); return Object.assign(x, { label:b.label, scolor:b.color, tagDark: Math.abs(Math.round(x.s)) === 2 }); }

  async function react(text, list, ai, kindLabel, intensity) {
    const a = analyse(text);
    let res = null, live = false;
    if (ai) { try { res = await aiReact(text, list, kindLabel); live = !!res; } catch (e) { res = null; } }
    if (!res) res = list.map(p => { const s = heur(text, p, a, intensity); return { p, s, q:fallbackQuote(text, p, s), t:a.theme }; });
    return { items:res.map(decorate), live };
  }

  function sampleOf(scope, n) {
    const big = personas(scope, 40), out = [], seen = {};
    for (const p of big) { if (out.length >= n) break; if ((seen[p.seg] || 0) < Math.ceil(n / 4)) { out.push(p); seen[p.seg] = (seen[p.seg] || 0) + 1; } }
    return out;
  }
  const div = v => ({ left:(v < 0 ? 50 + v * 25 : 50) + '%', width:Math.max(.6, Math.abs(v) * 25) + '%', color:v >= 0 ? '#2F6F5E' : '#C2492A', val:(v >= 0 ? '+' : '−') + Math.abs(Math.round(v * 50)) });

  async function simulate(text, scope, n, ai, kindLabel, intensity) {
    const a = analyse(text), info = get(scope);
    const sample = sampleOf(scope, n);
    const r = await react(text, sample, ai, kindLabel, intensity);
    const segOff = {}, cnt = {};
    r.items.forEach(x => { const d = x.s - heur(text, x.p, a, intensity); segOff[x.p.seg] = (segOff[x.p.seg] || 0) + d; cnt[x.p.seg] = (cnt[x.p.seg] || 0) + 1; });
    Object.keys(segOff).forEach(k => segOff[k] /= cnt[k]);
    const model = personas(scope, 120).map(p => ({ p, s:clamp(heur(text, p, a, intensity) + (segOff[p.seg] || 0), -2, 2) }));
    const mean = arr => arr.reduce((t, x) => t + x.s, 0) / (arr.length || 1);
    const net = Math.round(mean(model) * 50);
    const split = BUCKETS.map(b => { const c = model.filter(x => clamp(Math.round(x.s), -2, 2) === b.k).length; return { label:b.label, color:b.color, pct:Math.round(c / model.length * 100) }; });
    const bySeg = SEG_KEYS.map(k => { const g = model.filter(x => x.p.seg === k); return g.length ? Object.assign({ name:SEGS[k].name, dot:SEGS[k].color }, div(mean(g))) : null; }).filter(Boolean);
    let byArea = [];
    if (info.kind === 'uk' || info.kind === 'region') {
      const key = info.kind === 'uk' ? 'regionId' : 'clusterId', groups = {};
      model.forEach(x => (groups[x.p[key]] = groups[x.p[key]] || []).push(x));
      byArea = Object.keys(groups).filter(k => groups[k].length >= 3).map(k => Object.assign({ name:get(k).name, m:mean(groups[k]) }, div(mean(groups[k])))).sort((x, y) => y.m - x.m).slice(0, 8);
    }
    const th = {}; r.items.forEach(x => th[x.t] = (th[x.t] || 0) + 1);
    const themes = Object.keys(th).map(k => ({ name:k, n:th[k] })).sort((x, y) => y.n - x.n).slice(0, 6);
    const B = [['Adopt', x => x.s >= 1, '#2F6F5E'], ['Consider', x => x.s >= .25 && x.s < 1, '#8DBFA8'], ['Ignore', x => x.s > -.75 && x.s < .25, '#CFCAC2'], ['Reject', x => x.s <= -.75, '#A8321C']];
    const behaviour = B.map(b => { const pct = Math.round(model.filter(b[1]).length / model.length * 100); return { label:b[0], color:b[2], pct, est:fmtK(Math.round(info.count * pct / 100)) }; });
    return { items:r.items, live:r.live, net, netLabel:(net >= 0 ? '+' : '−') + Math.abs(net), split, bySeg, byArea, themes, behaviour, scopeName:info.name, scopeCount:fmt(info.count), modelled:model.length };
  }

  function scriptedReply(p, text) {
    const t = text.toLowerCase();
    if (/price|cost|pay|afford|spend|money|cheap|expensive|£/.test(t)) return `I’m fairly careful with money — ${p.buy.charAt(0).toLowerCase() + p.buy.slice(1)}. Truthfully, ${CON[p.seg]}, so anything new has to prove it’s worth it.`;
    if (/work|job|career|day/.test(t)) return `I’m a ${p.occ.toLowerCase()} here in ${p.loc}. Most weeks are busy; I fit everything else around it.`;
    if (/like|hobby|weekend|free time|enjoy|interest/.test(t)) return `When I get the time? ${p.interests[0]} mostly, and a bit of ${p.interests[1].toLowerCase()}. ${p.interests[2]} when I can.`;
    if (/trust|brand|switch|buy|shop/.test(t)) return `${p.att}. I’ll only switch if someone I know recommends it, or it clearly saves me money.`;
    const a = analyse(text), s = heur(text, p, a, 1);
    return fallbackQuote(text, p, s) + ` Speaking as a ${p.segName.toLowerCase()} in ${p.loc}, that’s my honest take.`;
  }
  async function chatReply(p, history, text, ai) {
    if (ai && window.claude && window.claude.complete) {
      try {
        const convo = history.map(m => (m.me ? 'Interviewer: ' : p.name.split(' ')[0] + ': ') + m.text).join('\n');
        const prompt = `Role-play this synthetic UK consumer persona in a research interview. Stay fully in character; never mention being an AI or a persona.\n${describe(p)}\n\nReply in first person, natural British English, 1–3 sentences, grounded in your circumstances.\n\n${convo}\nInterviewer: ${text}\n${p.name.split(' ')[0]}:`;
        const out = await window.claude.complete(prompt);
        if (out && String(out).trim()) return String(out).trim().replace(/^"|"$/g, '');
      } catch (e) {}
    }
    return scriptedReply(p, text);
  }

  return { REGIONS, CLUSTERS, SEGS, SEG_KEYS, HEADLINES, EVENT_TYPES, EVENT_PRESETS, TOTAL, BUCKETS, get, visibleAt, mix, personas, scopeOptions, fmt, fmtK, react, simulate, chatReply };
})();
